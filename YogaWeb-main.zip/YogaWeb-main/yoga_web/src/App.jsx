import './App.css'
// Others
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'

// For Components
import Navbar from './Layout/Navbar/Navbar'
import Footer from './Layout/Footer/Footer'

// For Pages
import Home from './Pages/Home/Home'
import About from './Pages/About/About'
import Session from './Pages/Sessions/Session'
import WhyPage from './Pages/WhyPage/WhyPage'
function App() {

  return (
    <>
      <Router>
        <Routes>
          <Route path='/' element={[<Navbar />, <Home />, <Footer />]}></Route>
          <Route path='/About' element={[<Navbar />, <About />, <Footer />]}></Route>
          <Route path='/Sessions' element={[<Navbar />, <Session />, <Footer />]}></Route>
          <Route path='/WhyPage' element={[<Navbar />, <WhyPage />, <Footer />]}></Route>
        </Routes>
      </Router>
    </>
  )
}

export default App
