import './AboutCardBox.css'
const AboutCardBox = ({ h6Title, h5Title }) => {
    return (
        <>
            <div className="AboutcardBox">
                <h6>{h6Title}</h6>
                <h5>{h5Title}</h5>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magnam culpa est amet incidunt, a
                    quod perspiciatis rem minima quis unde, fugit reiciendis nam, debitis excepturi veritatis
                    ipsa illo dolorem obcaecati. <br /><br />
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias iste eligendi sed expedita
                    ut. Aliquid ipsa quisquam consequuntur accusamus corrupti.

                </p>
            </div>
        </>
    )
}

export default AboutCardBox