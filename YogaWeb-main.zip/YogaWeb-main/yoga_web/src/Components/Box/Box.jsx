import './Box.css'
const Box = ({ ImgUrl, h5Title }) => {
    return (
        <>
            <div className="Box">
                <img src={ImgUrl} className='img-fluid' alt="Gallery  Img" />
                <div className="boxContent">
                    <h5>{h5Title}</h5>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta deserunt sint quia
                        minima laudantium pariatur mollitia quisquam facere odio hic sunt, molestiae accusamus
                        iusto libero magni temporibus ipsam! Itaque, facilis?

                    </p>
                </div>
            </div>
        </>
    )
}

export default Box