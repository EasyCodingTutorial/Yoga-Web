import './Button.css'
const Button = ({ buttonText }) => {
    return (
        <>
            <button className="btn">{buttonText}</button>
        </>
    )
}
export default Button