import './WhyPage.css'


// For Components
import MainPage from '../../Components/MainPage/MainPage'
import Content from '../../Components/Content/Content'
import Box from '../../Components/Box/Box'

const WhyPage = () => {
    return (
        <>
            <MainPage
                // We Are Passing This
                // BgImg, mainImg, h6Text, h5Text, h5SpanText, Quality, smalldetails ,Timing, Rating

                BgImg="\assets\whyPage\whymainHeader2.jpg"
                mainImg="\assets\whyPage\whymainHeader1.jpg"
                h6Text="Why us"
                h5Text="For"
                h5SpanText="Peace"
                Quality="6k"
                smalldetails="Choose us For Inner Peace"
                Timing="NA"
                Rating={9.7}

            />


            {/* Why You Choose us Reasons */}
            <div className="container WhyYouChooseus">
                <Content
                    // Passing h6Title, h5Title
                    h6Title="Reasons Why You Choose us"
                    h5Title="Why Choose us"
                />

                <div className="row">

                    <div className="col-sm-4">
                        <Box
                            // We Are Passing
                            //   ImgUrl, h5Title
                            ImgUrl="\assets\whyPage\whymainHeader1.jpg"
                            h5Title="Reason 1"
                        />
                    </div>    <div className="col-sm-4">
                        <Box
                            // We Are Passing
                            //   ImgUrl, h5Title
                            ImgUrl="\assets\whyPage\whymainHeader2.jpg"
                            h5Title="Reason 2"
                        />
                    </div><div className="col-sm-4">
                        <Box
                            // We Are Passing
                            //   ImgUrl, h5Title
                            ImgUrl="\assets\whyPage\whymainHeaderbg.jpg"
                            h5Title="Reason 2"
                        />
                    </div>






                </div>

            </div>
            {/* Why You Choose us Reasons */}

        </>
    )
}

export default WhyPage