import './Footer.css'
import { Link } from 'react-router-dom'
const Footer = () => {
    return (

        <>
            <footer>
                <nav className="navbar navbar-expand ">
                    <Link to="/" className='navbar-brand'><img src="/assets/logo.png" alt="Logo" /></Link>
                    <div>
                        <ul className="navbar-nav">
                            <li className="nav-item">
                                <Link to="/" className="nav-link">Home</Link>
                            </li>  <li className="nav-item">
                                <Link to="/" className="nav-link">About</Link>
                            </li><li className="nav-item">
                                <Link to="/" className="nav-link">Sessions</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/" className="nav-link">Why</Link>
                            </li>
                        </ul>
                    </div>

                </nav>

                {/* Custom */}
                <div className="customNav">
                    <div>
                        <ul>
                            <li>Faq</li>
                            <li>Privacy</li>
                            <li>Help Center</li>
                            <li>Pricing</li>
                            <li>Faq</li>
                        </ul>
                    </div>

                    <div>
                        <i className="fa-brands fa-facebook"></i>
                        <i className="fa-brands fa-twitter"></i>
                        <i className="fa-brands fa-instagram"></i>
                        <i className="fa-brands fa-github"></i>
                        <i className="fa-brands fa-linkedin"></i>
                    </div>

                </div>


                {/* For h6 */}
                <h6>&copy; <span> Easy Coding Tutorial</span> || All Right Reserved</h6>


            </footer>
        </>


    )
}

export default Footer