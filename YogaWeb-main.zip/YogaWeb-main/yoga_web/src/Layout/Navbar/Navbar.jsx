import Button from '../../Components/Button/Button'
import './Navbar.css'
import { Link } from 'react-router-dom'

// For Scrollbar
$(document).scroll(function () {
    $(".navbar").toggleClass("scroll", $(this).scrollTop() > $(".navbar").height())
})

const Navbar = () => {
    return (
        <>
            <nav className="navbar navbar-expand fixed-top">
                <Link to="/" className='navbar-brand'><img src="/assets/logo.png" alt="Logo" /></Link>

                {/* For Nav Links */}
                <div>
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <Link to="/" className="nav-link">Home</Link>
                        </li>  <li className="nav-item">
                            <Link to="/About" className="nav-link">About</Link>
                        </li><li className="nav-item">
                            <Link to="/Sessions" className="nav-link">Sessions</Link>
                        </li>
                        <li className="nav-item">
                            <Link to="/WhyPage" className="nav-link">Why</Link>
                        </li>
                    </ul>
                </div>

                {/* For Another Div */}
                <div className="secondDiv">

                    <i className="fas fa-search"></i>
                    <i className="fa-solid fa-globe"></i>

                    {/* For Options */}
                    <select name="" id="">
                        <option value="IN">IN</option>
                        <option value="IN">HN</option>
                        <option value="IN">EN</option>
                    </select>
                    <Button buttonText="Sign In" />
                </div>


            </nav>










        </>

    )
}

export default Navbar