import './Why.css'
const Why = () => {
    return (
        <>
            <div className="whyChooseus container">

                <div className="row justify-content-center">

                    <div className="col-sm-5">
                        <img src="/assets/whychooseus.png" className='img-fluid' alt="Why Choose us Img" />
                    </div>

                    <div className="col-sm-6">
                        <h6>Why Choose us</h6>
                        <h5>Yoga is A Therapy You Need a Professional With 20 Years of Experience</h5>

                        <p>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consequuntur quidem eius nam nisi odit
                            deserunt placeat consequatur quasi, in quisquam laborum rerum voluptatem est? Ad voluptatum
                            optio consequatur culpa iure. <br /><br />
                            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quidem itaque asperiores nobis
                            expedita, possimus illum est vel quae? Voluptatem dolorem molestias accusantium adipisci illum
                            tenetur, vel impedit fugit et, aliquid quam obcaecati dolores sit veniam dicta, facilis
                            voluptates velit. Quod?
                            <br /><br />
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda cum ullam provident. Iure
                            eius iusto laudantium voluptatem nisi nostrum nesciunt corporis maiores corrupti voluptatibus a,
                            obcaecati reiciendis harum, mollitia delectus!

                        </p>

                    </div>

                </div>

            </div>
        </>
    )
}

export default Why