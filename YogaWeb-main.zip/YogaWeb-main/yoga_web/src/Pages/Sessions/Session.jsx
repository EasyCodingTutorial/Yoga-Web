import './Session.css'


// For Components
import MainPage from '../../Components/MainPage/MainPage'
import Content from '../../Components/Content/Content'
import Box from '../../Components/Box/Box'
const Session = () => {
    return (
        <>
            <MainPage
                // We Are Passing This
                // BgImg, mainImg, h6Text, h5Text, h5SpanText, Quality, smalldetails ,Timing, Rating

                BgImg="assets\sessionPage\sessionMainBg.jpg"
                mainImg="/assets/sessionPage/sessionMainHeader.jpg"
                h6Text="Upcoming Session"
                h5Text="On "
                h5SpanText="1 Sept"
                Quality="6k"
                smalldetails="About Inner Peace"
                Timing="NA"
                Rating="NA"

            />

            {/* For upcoming Sessions */}
            <div className="UpcomingSessions container">
                <Content
                    // Passing h6Title, h5Title
                    h6Title="Time Table For Upcoming Sessions"
                    h5Title="Upcoming Sessions"
                />

                <div className="row">

                    <div className="col-sm-3">
                        <Box
                            // We Are Passing
                            // ImgUrl, h5Title
                            ImgUrl="/assets/headerimg.jpg"
                            h5Title="on 2 Sept 2023"
                        />
                    </div>

                    <div className="col-sm-3">
                        <Box
                            // We Are Passing
                            // ImgUrl, h5Title
                            ImgUrl="/assets/gallery1.jpg"
                            h5Title="on 4 Sept 2023"
                        />
                    </div>

                    <div className="col-sm-3">
                        <Box
                            // We Are Passing
                            // ImgUrl, h5Title
                            ImgUrl="/assets/gallery3.jpg"
                            h5Title="on 6 Sept 2023"
                        />
                    </div>

                    <div className="col-sm-3">
                        <Box
                            // We Are Passing
                            // ImgUrl, h5Title
                            ImgUrl="/assets/gallery4.jpg"
                            h5Title="on 9 Sept 2023"
                        />
                    </div>




                </div>


                {/* For Second Row */}
                <div className="row">

                    <div className="col-sm-3">
                        <Box
                            // We Are Passing
                            // ImgUrl, h5Title
                            ImgUrl="assets\sessionPage\sessionMainBg.jpg"
                            h5Title="on 16 Sept 2023"
                        />
                    </div>

                    <div className="col-sm-3">
                        <Box
                            // We Are Passing
                            // ImgUrl, h5Title
                            ImgUrl="/assets/sessionPage/sessionMainHeader.jpg"
                            h5Title="on 20 Sept 2023"
                        />
                    </div>

                    <div className="col-sm-3">
                        <Box
                            // We Are Passing
                            // ImgUrl, h5Title
                            ImgUrl="/assets/gallery5.jpg"
                            h5Title="on 29 Sept 2023"
                        />
                    </div>

                    <div className="col-sm-3">
                        <Box
                            // We Are Passing
                            // ImgUrl, h5Title
                            ImgUrl="/assets/gallery6.jpg"
                            h5Title="on 25 Sept 2023"
                        />
                    </div>




                </div>




            </div>
            {/* For upcoming Sessions */}

        </>
    )
}

export default Session