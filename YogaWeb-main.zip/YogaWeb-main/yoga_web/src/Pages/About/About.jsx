import './About.css'


// For Components
import MainPage from '../../Components/MainPage/MainPage'
import Why from '../../Components/Why/Why'
import Content from '../../Components/Content/Content'
import AboutCardBox from '../../Components/aboutCardBox/AboutCardBox'

const About = () => {
    return (

        <>
            {/* For Main Header */}

            <MainPage
                // We Are Passing This
                // BgImg, mainImg, h6Text, h5Text, h5SpanText, Quality, smalldetails ,Timing, Rating

                BgImg="/assets/headerimg.jpg"
                mainImg="/assets/aboutPage/aboutmainHeader.jpg"
                h6Text="About us"
                h5Text="Zero To"
                h5SpanText="Hero"
                Quality="6k"
                smalldetails="Peace, Peace, Peace"
                Timing="NA"
                Rating={9.7}

            />

            {/* Why Choose us */}
            <Why />

            {/* For About Card/Process */}
            <div className="aboutCard container">
                <Content
                    // Passing h6Title, h5Title
                    h6Title="How All Starts And Hows All Going"
                    h5Title="Our Process"
                />

                <div className="row">

                    <div className="col-sm-3">
                        <AboutCardBox h6Title="Step 1" h5Title="Process 1" />
                    </div>

                    <div className="col-sm-3">
                        <AboutCardBox h6Title="Step 2" h5Title="Process 2" />
                    </div>
                    <div className="col-sm-3">
                        <AboutCardBox h6Title="Step 3" h5Title="Process 3" />
                    </div>       <div className="col-sm-3">
                        <AboutCardBox h6Title="Step 4" h5Title="Process 4" />
                    </div>


                </div>

                {/* Second Row */}
                <div className="row">

                    <div className="col-sm-3">
                        <AboutCardBox h6Title="Step 5" h5Title="Process 5" />
                    </div>

                    <div className="col-sm-3">
                        <AboutCardBox h6Title="Step 6" h5Title="Process 6" />
                    </div>
                    <div className="col-sm-3">
                        <AboutCardBox h6Title="Step 7" h5Title="Process 7" />
                    </div>       <div className="col-sm-3">
                        <AboutCardBox h6Title="Step 8" h5Title="Process 8" />
                    </div>


                </div>




            </div>
            {/* For About Card/Process */}


        </>


    )
}

export default About