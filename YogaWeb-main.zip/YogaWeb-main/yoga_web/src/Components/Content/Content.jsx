import './Content.css'
const Content = ({ h6Title, h5Title }) => {
    return (
        <div className="Content">
            <h6>{h6Title}</h6>
            <h5>{h5Title}</h5>
        </div>

    )
}

export default Content