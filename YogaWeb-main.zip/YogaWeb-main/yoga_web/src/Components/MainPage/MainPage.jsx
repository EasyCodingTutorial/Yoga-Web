import './MainPage.css'
import Button from '../Button/Button'
import { Link } from 'react-router-dom'
const MainPage = ({ BgImg, mainImg, h6Text, h5Text, h5SpanText, Quality, smalldetails, Timing, Rating }) => {
    return (
        <>
            {/*  */}
            <div className="mainPageHome">
                <div>
                    <div className="img">
                        <img src={BgImg} className='img-fluid' alt="Bg Img" />
                    </div>
                    <div className="mainPageHomeOverlay"></div>
                </div>
                <div className="mainPageHomeContent">

                    {/*  */}
                    <div className="container">
                        <div className="row">
                            <div className="col-sm-5">
                                <div className="box">
                                    <Link to="https:youtube.com/c/EasyCodingTutorial" target='_blank'>
                                        <img src={mainImg} className='img-fluid' alt="Main Container Img" />
                                        <div className="boxContent">
                                            <i className="fas fa-play"></i>
                                        </div>
                                    </Link>
                                </div>
                            </div>


                            {/*  */}
                            <div className="offset-sm-1 col-sm-6">
                                <h6>{h6Text}</h6>
                                <h5>{h5Text} <span>{h5SpanText}</span></h5>
                                {/* For Small Details */}
                                <div>
                                    <span className="Quality">{Quality}</span>
                                    <span>{smalldetails}</span>
                                    <span><i className="fa-solid fa-clock"></i> {Timing}</span>
                                    <span><i className="fas fa-star"></i> {Rating}</span>
                                </div>

                                <p>
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde explicabo doloremque nesciunt
                                    voluptatum culpa accusamus voluptates dolorum facilis totam odio. <br />
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim, laborum.

                                </p>

                                {/* Streaming On */}
                                <div className="customBox">
                                    <div>
                                        <i className="fa-solid fa-share-nodes"></i>
                                        <h6>Share</h6>
                                    </div>

                                    <div>
                                        <h6>Streaming on</h6>
                                        <h3>Easy Networks</h3>
                                    </div>

                                    <div>
                                        <Button buttonText="Watch Now" />
                                    </div>


                                </div>


                            </div>
                            {/*  */}



                        </div>
                    </div>
                    {/*  */}

                </div>
            </div>
            {/*  */}




        </>
    )
}

export default MainPage