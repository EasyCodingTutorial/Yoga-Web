import Box from '../../Components/Box/Box'
import Content from '../../Components/Content/Content'
import Why from '../../Components/Why/Why'
import './Home.css'
const Home = () => {
    return (
        <>
            {/* For Home main */}
            <div className="Home">
                <div>
                    <video src="/assets/headerVideo.mp4" className='img-fluid' autoPlay muted loop></video>
                    <div className="VidOverlay"></div>
                </div>
                <div className="VidContent">
                    <h6>
                        Yoga is a Therapy Why Not Do With Us
                    </h6>
                </div>
            </div>
            {/* For Home main */}


            {/* Why Choose us */}
            <Why />
            {/* Why Choose us */}

            {/* Custom Start */}
            <div className="custom container">
                <h6>You Need a Professional With 20 Years of Experience, Its Means You Wants Us Why Not Drop us A <span> Message</span></h6>
            </div>
            {/* Custom End */}

            {/* Gallery Start */}
            <div className="Gallery container">
                <Content h6Title="Take a Close Look To Our Gallery" h5Title="Our Gallery" />

                <div className="row">

                    <div className="col-sm-3">
                        <Box ImgUrl="/assets/gallery1.jpg" />
                    </div>

                    <div className="col-sm-3">
                        <Box ImgUrl="/assets/gallery2.jpg" />
                    </div>

                    <div className="col-sm-3">
                        <Box ImgUrl="/assets/gallery3.jpg" />
                    </div>

                    <div className="col-sm-3">
                        <Box ImgUrl="/assets/gallery4.jpg" />
                    </div>




                </div>


                {/* Second Row */}
                <div className="row">

                    <div className="col-sm-3">
                        <Box ImgUrl="/assets/gallery5.jpg" />
                    </div>

                    <div className="col-sm-3">
                        <Box ImgUrl="/assets/gallery6.jpg" />
                    </div>

                    <div className="col-sm-3">
                        <Box ImgUrl="/assets/gallery7.jpg" />
                    </div>

                    <div className="col-sm-3">
                        <Box ImgUrl="/assets/gallery8.jpg" />
                    </div>




                </div>


            </div>
            {/* Gallery End */}

            {/* Blogs */}
            <div className="Blogs container">
                <Content h6Title="Take A Close Look To Our Blogs" h5Title="Our Blogs" />

                <div className="row justify-content-center">

                    <div className="col-sm-5">
                        <Box ImgUrl="/assets/Blog1.jpg" h5Title="Blog Title: You Need a Professional.." />
                    </div>
                    <div className="col-sm-5">
                        <Box ImgUrl="/assets/Blog2.jpg" h5Title="Blog Title: You Need a Professional.." />
                    </div>

                </div>

            </div>





        </>
    )
}

export default Home